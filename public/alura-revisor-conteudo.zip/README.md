# Alura Revisor de Conteúdo

Extensão de navegador para equipes de conteúdo da Alura. Automatiza revisão de cursos, upload de vídeos, auditoria de transcrições e legendas, upload de material de apoio e outras operações do dia a dia.

---

## Instalação

### Via Hub de Conteúdo (recomendado)

1. Acesse o [Hub de Conteúdo](https://hub-producao-conteudo.vercel.app) e faça login
2. Baixe o zip da extensão disponível na página
3. Descompacte o zip
4. Abra `chrome://extensions` no navegador
5. Ative o **Modo do desenvolvedor**
6. Clique em **Carregar sem compactação** e selecione a pasta descompactada

### Atualizando

Execute o arquivo `atualizar.bat` que vem na pasta da extensão. Ele baixa a versão mais recente e instrui os próximos passos. Após o download, acesse `chrome://extensions` e clique em **Recarregar** na extensão.

---

## Autenticação

A extensão depende do **[Hub de Conteúdo](https://hub-producao-conteudo.vercel.app)** para funcionar. As credenciais (GitHub, video-uploader, AWS Bedrock, S3) são armazenadas centralmente no hub — não é necessário configurar nada localmente.

Faça login no hub antes de usar qualquer ferramenta que dependa de credenciais. A aba **Credenciais** da extensão mostra o link de acesso ao hub e permite configurar o Dropbox (que ainda requer configuração local).

---

## Módulos

### Aba Revisão

#### Start revisão

Executa auditoria completa de um curso. Deve ser iniciado na **Home do curso**.

O que verifica:

- Campos do admin: meta descrição, público-alvo, "Faça esse curso e...", ementa, horas estimadas
- **Código do curso** — deve conter apenas letras minúsculas, números e hífens simples, com ao menos duas palavras
- Transcrição de cada vídeo (mínimo de 50 caracteres)
- Links quebrados (404)
- Links com `href` vazio
- Links do GitHub fora do padrão oficial
- Links de armazenamento em nuvem não oficiais (Dropbox, OneDrive, etc.)
- Presença do curso nos catálogos corretos
- Presença do curso em uma subcategoria
- Upload do ícone de categoria quando o curso está em uma subcategoria
- Ao menos 2 exercícios habilitados para a Luri
- Ao menos 2 atividades "O que aprendemos?" habilitadas para a Luri
- Nomes genéricos de seções ("Aula 1", "Aula 2"..., "Classe 1", "Classe 2"...)

A extensão suporta o **novo layout de curso** (acesso antecipado), identificando seções via `ds-accordion-item`, transcrições pelo atributo `aria-label="Transcrição: …"` e subcategoria pelo título "Faça esse curso de X e:". No novo layout, upload de ícone e adição temporária ao catálogo Alura são pulados, pois o breadcrumb não está disponível.

Durante a revisão, se o curso não estiver em um catálogo, um modal aparece para selecionar e adicionar automaticamente. O mesmo acontece para subcategoria.

Para cada vídeo encontrado, a extensão abre a atividade em segundo plano para forçar o registro da duração no player, mantendo a estimativa de horas atualizada.

Se a ordem das atividades estiver com atividade inativa na frente bloqueando o acesso ao curso, a ferramenta corrige automaticamente.

Ao finalizar, exibe um relatório completo com opção de download em `.txt` e `.json`. O histórico das últimas 5 auditorias fica salvo na extensão.

Quando há erros nos campos admin (carga horária, ementa ou código do curso), um botão **Corrigir Admin** aparece no relatório. Ao clicar, a extensão abre a página admin em segundo plano e aplica as correções automáticas:

| Campo | Correção automática |
|-------|---------------------|
| Carga horária | Horas estimadas pelo sistema + 2h (máximo 20h) |
| Ementa | Gerada a partir dos títulos dos vídeos de cada seção (formato `-Seção\n*Vídeo`) |

Quando há seções com nomes genéricos, um botão **Sugestão dos nomes das aulas** aparece no relatório e aciona diretamente o fluxo de renomeação via IA.

Se o ícone do curso não pôde ser verificado por falta de login no hub, o relatório exibe `⚠️ Ícone não enviado (sem login no Hub de Conteúdo)`.

---

#### Cursos Em Breve

Cursos com "Em Breve" no nome seguem um fluxo reduzido, pois suas aulas estão desativadas e os campos admin são provisórios.

O que **muda** em relação à revisão normal:

- Todas as seções e aulas são revisadas, inclusive as desativadas
- Links e transcrições são verificados normalmente via admin
- Carga de duração dos vídeos é pulada
- Campos admin não são verificados nem corrigidos
- O relatório exibe um aviso **🚧 Curso Em Breve**

---

### Aba Ferramentas

#### Fork → alura-cursos

Cria um fork de um repositório GitHub para a organização `alura-cursos`.

1. Cole a URL do repositório do instrutor
2. Clique em **Fazer Fork**

Se o fork já existir, retorna a URL existente sem criar um duplicado. Requer login no hub.

---

#### Auditoria de transcrições e legendagens

Audita múltiplos cursos de uma vez, identificando vídeos com pendências.

1. Cole os IDs dos cursos separados por vírgula ou espaço
2. Selecione o que deseja verificar:
   - **Transcrição** — verifica se o vídeo tem transcrição com mais de 50 caracteres
   - **Legendas em PT** — verifica se a legenda em Português está disponível no player
   - **Legendas em ESP** — verifica se a legenda em Espanhol está disponível no player
   - **Download textual** — extrai e baixa o conteúdo completo dos cursos em Markdown
3. Clique em **Auditar lista**

O relatório final é dividido em **Resumo** (visão consolidada por curso) e **Detalhado** (lista de cada vídeo com pendência). Opções de exportação: **Copiar** e **Baixar .txt**.

A auditoria fica salva no **Histórico** da extensão com data e hora.

##### Download textual de cursos

Disponível como opção na auditoria em lote. Quando ativado, baixa o conteúdo estruturado de cada curso em Markdown ao finalizar.

O que é extraído por curso:
- Nome, traduções (EN/ES), carga horária, meta description, público-alvo, autores e ementa
- Todas as seções e atividades com seus tipos
- Transcrições dos vídeos
- Alternativas corretas de atividades (incluindo justificativas)

Formatos de download: **um arquivo por curso** (`{id}-{slug}.md`) e **arquivo consolidado** com todos os cursos.

---

#### Criação de cursos Caixaverso

Cria cursos no formato Caixaverso em lote a partir de uma lista de nomes. Após a criação, permite subir os vídeos correspondentes diretamente do Dropbox.

1. Informe os nomes dos cursos (um por linha)
2. Clique em **Criar cursos**
3. Quando os vídeos estiverem no Dropbox, clique em **Subir vídeos do Dropbox**

---

#### Vídeos do curso

Deve ser iniciado na **Home do curso**.

- **Baixar vídeos do curso** — navega pelo curso automaticamente e baixa todos os vídeos para o computador. Nomenclatura: `{courseId}-video{seção}.{vídeo}-alura-{título}.mp4`
- **Trocar vídeos Vimeo ↔ Uploader** — envia os vídeos para o `video-uploader.alura.com.br`, gera legendas em PT e ES, e atualiza o campo `URI` de cada atividade no admin
- **Subir legendas do curso** *(em testes)* — sobe as legendas dos vídeos do curso

O módulo de subir vídeos:
1. Cria ou localiza uma showcase com o ID do curso no video-uploader
2. Faz upload serial de cada vídeo
3. Clica em **Gerar legenda** em cada vídeo após o upload
4. Atualiza o campo `URI` das atividades no admin

Vídeos com streaming HLS são marcados com `⚠️` e não são enviados. Requer login no hub.

---

#### Transferência para LATAM

Copia automaticamente todas as atividades não-vídeo de um curso Alura para um curso LATAM (`app.aluracursos.com`), usando as traduções em espanhol disponíveis. Deve ser iniciado na **Home do curso** em `cursos.alura.com.br`.

1. Informe o **ID do curso LATAM** de destino
2. Clique em **Enviar atividades traduzidas direto para plataforma Latam**

O que faz automaticamente:
1. Lê todas as seções ativas do curso Alura
2. Cria as seções correspondentes no curso LATAM
3. Para cada atividade de texto, busca a tradução em espanhol e cria a atividade no LATAM com título, corpo e alternativas preenchidos

O botão **Baixar atividades traduzidas** gera um JSON com o conteúdo em espanhol de todas as atividades, salvo localmente para uso imediato na transferência.

---

#### Renomear Seções com IA

Renomeia automaticamente seções genéricas do curso ("Aula 1", "Aula 2"...) com títulos descritivos gerados via **Amazon Titan** (AWS Bedrock). Pode ser iniciado na Home do curso ou pelo botão **Sugestão dos nomes das aulas** no relatório final da revisão.

- Identifica seções com nomes genéricos
- Usa a transcrição dos vídeos de cada seção como contexto
- Gera um título descritivo (máximo 6 palavras)
- Exibe as sugestões em um overlay para aprovação e edição antes de salvar

Seções sem transcrição são puladas. Requer login no hub.

---

#### Upload ícone Start

Faz o upload do ícone de categoria para cursos no formato Start. Deve ser iniciado na **Home do curso Start**.

Clique em **Upload ícone Start** — a extensão detecta a categoria pelo breadcrumb e envia o ícone correspondente ao repositório. Requer login no hub.

---

#### Upload de Material

Sobe arquivos de apoio (PDF, XLSX, ZIP, etc.) diretamente para o CDN e gera o link de download para uso nas atividades do curso.

1. Informe o **ID + nome da pasta do curso** (ex: `4247-excel-rh` ou `4247 - Excel para RH`) — preenchido automaticamente se estiver na página do curso
2. Informe uma **subpasta** opcional (ex: `Projeto`, `Correção`)
3. Selecione um **arquivo** ou uma **pasta** inteira
4. Clique em **Fazer Upload**

O link CDN é exibido ao final com botão **Copiar link**. Para múltiplos arquivos, cada link aparece individualmente com botão de copiar e abrir.

O histórico dos últimos uploads fica salvo na extensão. Se o popup for fechado durante o upload, os links dos arquivos já enviados ficam salvos e são recuperados ao reabrir.

Requer login no hub.

---

### Aba Credenciais

#### Hub de Conteúdo

Todas as credenciais (GitHub, video-uploader, AWS Bedrock, S3) são gerenciadas centralmente no [Hub de Conteúdo](https://hub-producao-conteudo.vercel.app). Faça login lá para usar as ferramentas.

#### Dropbox

Configuração local necessária para usar o módulo de **Criação de cursos Caixaverso** (subir vídeos do Dropbox).

1. Informe o **App Key (Client ID)** do app Dropbox
2. Adicione o URI de redirecionamento exibido nas configurações do app Dropbox (OAuth 2 → Redirect URIs)
3. Clique em **Conectar Dropbox**

---

## Arquitetura

```
alura-revisor-conteudo/
├── manifest.json              # Configuração da extensão (MV3)
├── background.js              # Service worker — handlers de mensagens e operações em abas
├── content.js                 # Script injetado na Alura — orquestra os fluxos de revisão
├── content-admin.js           # Script injetado nas páginas admin da Alura
├── content-dropbox.js         # Script injetado no Dropbox — seleção de vídeos Caixaverso
├── content-hub.js             # Script injetado no Hub — repassa credenciais para a extensão
├── content-ferramentas-ia.js  # Script injetado no ferramentas-ia.alura.dev
├── popup.html                 # Interface da extensão
├── popup.js                   # Lógica da interface
└── icons/                     # Ícones SVG por categoria de curso
```

**Fluxo de comunicação:**

```
popup.js
  └─► chrome.tabs.sendMessage ──► content.js
                                      └─► chrome.runtime.sendMessage ──► background.js
                                                                              └─► abre abas ocultas
                                                                              └─► executa scripts
                                                                              └─► retorna dados
```

As operações que exigem acesso ao admin ou ao video-uploader são feitas pelo `background.js`, que abre abas em segundo plano, extrai os dados via `executeScript` e fecha as abas automaticamente.

O estado de execução é persistido em `chrome.storage.local`. Se a aba do curso for fechada durante um fluxo, a extensão retoma de onde parou ao reabrir a página.

As credenciais são carregadas pelo `content-hub.js` a partir do Hub de Conteúdo e armazenadas em `chrome.storage.session` (duram até fechar o navegador). A assinatura das requisições ao Amazon Bedrock usa **AWS SigV4** implementada via `crypto.subtle`, sem dependências externas.

Os uploads de material vão direto do popup para o CDN via **presigned URL** gerada pelo hub — sem passar pelo service worker, evitando limitações de serialização do `chrome.runtime.sendMessage`.

---

## Permissões utilizadas

| Permissão | Uso |
|-----------|-----|
| `scripting` | Executa scripts em abas do admin e video-uploader |
| `storage` | Salva estado de execução, histórico de auditorias e configurações |
| `notifications` | Notifica ao finalizar auditorias e uploads |
| `downloads` | Baixa arquivos de vídeo e relatórios de auditoria |
| `activeTab` | Acessa a aba ativa ao iniciar operações |
| `tabs` | Monitora navegação para detectar conclusão de login e fluxos multi-aba |
| `identity` | Suporte a fluxos OAuth |
| `alarms` | Agenda verificações periódicas (ex: atualização de versão) |
| `https://*/*` | Acessa admin, video-uploader, CDN da Alura, GitHub API e Hub de Conteúdo |
