// content-hub.js — injected into https://hub-producao-conteudo.vercel.app/*
//
// Protocol (fire-and-forget, no ACK):
//   Hub  → Extension : HUB_PAGE_READY      — page mounted
//   Hub  → Extension : HUB_EXPORT_REQUEST  — "Subir no Admin" clicked
//   Extension → Hub  : EXTENSION_UPLOAD_DONE — upload finished

(function () {
  "use strict";

  // Platform pre-selected via the extension popup (optional).
  // When set, skip the platform modal and go straight to upload.
  let platformFromPopup = null;

  // ── 1. Hub messages ───────────────────────────────────────────────────────

  window.addEventListener("message", function (event) {
    if (event.source !== window) return;

    if (event.data?.type === "HUB_EXPORT_REQUEST") {
      const payload = event.data;
      if (!payload?.courseId || !Array.isArray(payload?.sections)) return;

      if (platformFromPopup) {
        const platform = platformFromPopup;
        platformFromPopup = null;
        showUploadOverlay(payload, platform);
      } else {
        showPlatformModal(payload);
      }
    }
  });

  // ── 2. Extension popup button ─────────────────────────────────────────────
  // Pre-selects the platform and programmatically clicks "Subir no Admin",
  // which causes the hub to fire HUB_EXPORT_REQUEST.

  chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
    if (msg?.type !== "ALURA_REVISOR_HUB_UPLOAD") return;

    const uploadBtn = [...document.querySelectorAll("button")]
      .find((b) => b.textContent.includes("Subir no Admin"));

    if (!uploadBtn) {
      sendResponse({ ok: false, error: "Botão 'Subir no Admin' não encontrado na página." });
      return;
    }

    platformFromPopup = msg.platform || "alura";
    sendResponse({ ok: true });
    uploadBtn.click();
    return true;
  });

  // ── 3. Platform selection modal ───────────────────────────────────────────

  let modalHost = null;

  function showPlatformModal(payload) {
    if (modalHost) modalHost.remove();

    modalHost = document.createElement("div");
    modalHost.id = "alura-hub-modal-host";
    if (document.documentElement.classList.contains("dark")) {
      modalHost.dataset.theme = "dark";
    }
    Object.assign(modalHost.style, {
      position: "fixed",
      inset: "0",
      zIndex: "2147483647",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.55)",
    });

    const shadow = modalHost.attachShadow({ mode: "closed" });
    shadow.appendChild(buildModalStyles());

    const modal = document.createElement("div");
    modal.className = "modal";
    modal.innerHTML = `
      <div class="modal-header">
        <h2>Subir atividades no Admin</h2>
        <p>Selecione a plataforma de destino</p>
      </div>
      <div class="modal-body">
        <div class="course-badge">Curso <strong>${payload.courseId}</strong></div>
        <div style="display:flex;flex-direction:column;gap:8px;">
          <span class="field-label">Plataforma</span>
          <div class="radio-group">
            <label><input type="radio" name="platform" value="alura" checked> Alura</label>
            <label><input type="radio" name="platform" value="latam"> Latam</label>
          </div>
        </div>
        <div class="progress-box" id="progress-box"></div>
        <div class="result-box" id="result-box" style="display:none;"></div>
      </div>
      <div class="modal-footer" id="actions">
        <button class="btn-cancel" id="btn-cancel">Cancelar</button>
        <button class="btn-upload" id="btn-upload">Fazer upload</button>
      </div>
    `;

    shadow.appendChild(modal);
    document.body.appendChild(modalHost);

    shadow.getElementById("btn-cancel").addEventListener("click", () => {
      modalHost.remove();
      modalHost = null;
    });

    shadow.getElementById("btn-upload").addEventListener("click", () => {
      const platform = shadow.querySelector("input[name='platform']:checked")?.value || "alura";
      startUpload(payload, platform, shadow);
    });
  }

  // ── 4. Upload overlay (platform already known from popup) ─────────────────

  function showUploadOverlay(payload, platform) {
    if (modalHost) modalHost.remove();

    modalHost = document.createElement("div");
    modalHost.id = "alura-hub-modal-host";
    if (document.documentElement.classList.contains("dark")) {
      modalHost.dataset.theme = "dark";
    }
    Object.assign(modalHost.style, {
      position: "fixed",
      inset: "0",
      zIndex: "2147483647",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.55)",
    });

    const shadow = modalHost.attachShadow({ mode: "closed" });
    shadow.appendChild(buildModalStyles());

    const platformLabel = platform === "latam" ? "Latam" : "Alura";
    const modal = document.createElement("div");
    modal.className = "modal";
    modal.innerHTML = `
      <div class="modal-header">
        <h2>Enviando atividades…</h2>
        <p>Curso <strong style="color:#0c0d0e;font-weight:700">${payload.courseId}</strong> → ${platformLabel}</p>
      </div>
      <div class="modal-body">
        <div class="progress-box" id="progress-box"></div>
        <div class="result-box" id="result-box" style="display:none;"></div>
      </div>
      <div class="modal-footer" id="actions" style="display:none;">
        <button class="btn-close" id="btn-close">Fechar</button>
      </div>
    `;

    shadow.appendChild(modal);
    document.body.appendChild(modalHost);

    startUpload(payload, platform, shadow);
  }

  // ── 5. Shared styles ──────────────────────────────────────────────────────

  function buildModalStyles() {
    const style = document.createElement("style");
    style.textContent = `
      @import url('https://fonts.googleapis.com/css2?family=Encode+Sans:wght@400;700;800&family=JetBrains+Mono:wght@500&display=swap');

      * { box-sizing: border-box; margin: 0; padding: 0; }

      .modal {
        background: #ffffff;
        border-radius: 12px;
        border: 1px solid #e1e2e5;
        width: 400px;
        max-width: 95vw;
        box-shadow: 0 4px 24px rgba(0,0,0,0.10), 0 1px 4px rgba(0,0,0,0.06);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        font-family: system-ui, sans-serif;
      }

      .modal-header {
        padding: 20px 24px 18px;
        background: #f2f2f3;
        border-bottom: 1px solid #e1e2e5;
        display: flex;
        flex-direction: column;
        gap: 3px;
      }
      .modal-header h2 {
        font-family: 'Encode Sans', system-ui, sans-serif;
        font-size: 15px;
        font-weight: 700;
        color: #0c0d0e;
        letter-spacing: -0.01em;
      }
      .modal-header p {
        font-size: 12px;
        color: #46474e;
      }

      .modal-body {
        padding: 20px 24px;
        display: flex;
        flex-direction: column;
        gap: 16px;
      }

      .course-badge {
        background: #f2f2f3;
        border: 1px solid #e1e2e5;
        border-radius: 8px;
        padding: 8px 12px;
        font-family: 'JetBrains Mono', monospace;
        font-size: 12px;
        color: #46474e;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .course-badge strong {
        color: #0c0d0e;
        font-weight: 500;
      }

      .field-label {
        font-size: 11px;
        font-weight: 600;
        color: #46474e;
        text-transform: uppercase;
        letter-spacing: 0.07em;
        font-family: 'JetBrains Mono', monospace;
      }

      .radio-group { display: flex; gap: 8px; }
      .radio-group label {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 10px 14px;
        border: 1px solid #e1e2e5;
        border-radius: 10px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 600;
        color: #46474e;
        background: #f2f2f3;
        transition: border-color 0.15s, background 0.15s, color 0.15s;
      }
      .radio-group label:has(input:checked) {
        border-color: #052fd3;
        background: #eef1fd;
        color: #052fd3;
      }
      .radio-group input { accent-color: #052fd3; }

      .modal-footer {
        padding: 14px 24px;
        background: #f2f2f3;
        border-top: 1px solid #e1e2e5;
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }

      .progress-box { display: flex; flex-direction: column; gap: 8px; }
      .progress-box:empty { display: none; }
      .progress-label {
        font-family: 'JetBrains Mono', monospace;
        font-size: 11px;
        font-weight: 500;
        color: #46474e;
        text-transform: uppercase;
        letter-spacing: 0.06em;
      }
      .progress-text { font-size: 13px; color: #0c0d0e; line-height: 1.5; }
      .progress-bar-wrap {
        background: #e1e2e5;
        border-radius: 99px;
        height: 5px;
        overflow: hidden;
      }
      .progress-bar {
        height: 100%;
        background: #052fd3;
        border-radius: 99px;
        transition: width 0.3s;
        width: 0%;
      }

      .result-box { font-size: 13px; color: #0c0d0e; line-height: 1.6; }
      .result-box .ok { color: #166534; font-weight: 700; }
      .result-box .err { color: #b8001f; font-weight: 700; }

      .btn-cancel, .btn-close {
        padding: 8px 16px;
        border: 1px solid #e1e2e5;
        border-radius: 10px;
        background: #ffffff;
        color: #46474e;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.15s;
        font-family: system-ui, sans-serif;
      }
      .btn-cancel:hover, .btn-close:hover { background: #e1e2e5; }

      .btn-upload {
        padding: 8px 20px;
        border: none;
        border-radius: 10px;
        background: #052fd3;
        color: #ffffff;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        transition: opacity 0.15s;
        font-family: system-ui, sans-serif;
      }
      .btn-upload:hover { opacity: 0.85; }
      .btn-upload:disabled { opacity: 0.45; cursor: not-allowed; }

      /* ── Dark mode ── */
      :host([data-theme="dark"]) .modal        { background: #0c0d0e; border-color: #2a2b2f; }
      :host([data-theme="dark"]) .modal-header { background: #111213; border-color: #2a2b2f; }
      :host([data-theme="dark"]) .modal-header h2   { color: #f4f5f6; }
      :host([data-theme="dark"]) .modal-header p    { color: #888d96; }
      :host([data-theme="dark"]) .modal-footer { background: #111213; border-color: #2a2b2f; }
      :host([data-theme="dark"]) .course-badge {
        background: #191a1d; border-color: #2a2b2f; color: #888d96;
      }
      :host([data-theme="dark"]) .course-badge strong { color: #f4f5f6; }
      :host([data-theme="dark"]) .field-label  { color: #888d96; }
      :host([data-theme="dark"]) .radio-group label {
        background: #191a1d; border-color: #2a2b2f; color: #888d96;
      }
      :host([data-theme="dark"]) .radio-group label:has(input:checked) {
        border-color: #052fd3; background: #0d1240; color: #7b9bff;
      }
      :host([data-theme="dark"]) .progress-label { color: #888d96; }
      :host([data-theme="dark"]) .progress-text  { color: #f4f5f6; }
      :host([data-theme="dark"]) .progress-bar-wrap { background: #2a2b2f; }
      :host([data-theme="dark"]) .result-box     { color: #f4f5f6; }
      :host([data-theme="dark"]) .btn-cancel,
      :host([data-theme="dark"]) .btn-close {
        background: #191a1d; border-color: #2a2b2f; color: #888d96;
      }
      :host([data-theme="dark"]) .btn-cancel:hover,
      :host([data-theme="dark"]) .btn-close:hover { background: #2a2b2f; }
    `;
    return style;
  }

  // ── 6. Upload orchestration ───────────────────────────────────────────────

  async function startUpload(payload, platform, shadow) {
    const btnUpload = shadow.getElementById("btn-upload");
    const btnCancel = shadow.getElementById("btn-cancel");
    const progressBox = shadow.getElementById("progress-box");
    const resultBox = shadow.getElementById("result-box");
    const actions = shadow.getElementById("actions");

    if (btnUpload) btnUpload.disabled = true;
    if (btnCancel) btnCancel.style.display = "none";

    const courseId = String(payload.courseId);
    const createSection = platform === "latam"
      ? "ALURA_REVISOR_CREATE_LATAM_SECTION"
      : "ALURA_REVISOR_CREATE_ALURA_SECTION";
    const createTask = platform === "latam"
      ? "ALURA_REVISOR_CREATE_LATAM_TASK"
      : "ALURA_REVISOR_CREATE_ALURA_TASK";
    const courseIdKey = platform === "latam" ? "latamCourseId" : "aluraCourseId";
    const sectionIdKey = platform === "latam" ? "latamSectionId" : "aluraSectionId";

    const totalSections = payload.sections.length;
    const validActivities = payload.sections.reduce(
      (sum, s) => sum + s.activities.filter((a) => !a.skipped && !a.error).length,
      0
    );
    let doneActivities = 0;
    let errors = 0;

    // Build progress UI
    progressBox.innerHTML = `
      <span class="progress-label" id="progress-label">Seção 0/${totalSections}</span>
      <div class="progress-text" id="progress-text"></div>
      <div class="progress-bar-wrap"><div class="progress-bar" id="progress-bar"></div></div>
    `;

    function updateProgress(sectionIdx, activityLabel) {
      const pct = validActivities > 0 ? Math.round((doneActivities / validActivities) * 100) : 0;
      shadow.getElementById("progress-bar").style.width = pct + "%";
      shadow.getElementById("progress-label").textContent = `Seção ${sectionIdx + 1}/${totalSections}`;
      shadow.getElementById("progress-text").innerHTML = activityLabel
        ? `→ "${activityLabel}"`
        : "";
    }

    for (let si = 0; si < payload.sections.length; si++) {
      const section = payload.sections[si];
      updateProgress(si, null);

      let sectionResp;
      try {
        sectionResp = await chrome.runtime.sendMessage({
          type: createSection,
          [courseIdKey]: courseId,
          sectionName: section.title,
        });
      } catch (e) {
        sectionResp = { ok: false, error: e.message };
      }

      if (!sectionResp?.ok) {
        errors += section.activities.filter((a) => !a.skipped && !a.error).length;
        console.warn(`[Hub Upload] Falha ao criar seção "${section.title}":`, sectionResp?.error);
        continue;
      }

      for (const activity of section.activities) {
        if (activity.skipped || activity.error) continue;

        updateProgress(si, activity.title || activity.id);

        try {
          const taskResp = await chrome.runtime.sendMessage({
            type: createTask,
            [courseIdKey]: courseId,
            [sectionIdKey]: sectionResp.sectionId,
            taskEnum: activity.taskEnum,
            dataTag: activity.dataTag,
            title: activity.title,
            body: activity.body,
            opinion: activity.opinion || "",
            alternatives: activity.alternatives || [],
          });
          taskResp?.ok ? doneActivities++ : errors++;
        } catch (e) {
          errors++;
          console.warn(`[Hub Upload] Erro na atividade "${activity.title}":`, e.message);
        }
      }
    }

    // Report result back to the hub (for toast/feedback)
    const platformLabel = platform === "latam" ? "Latam" : "Alura";
    window.postMessage({
      type: "EXTENSION_UPLOAD_DONE",
      success: errors === 0,
      count: doneActivities,
      errors,
      platform: platformLabel,
    }, "*");

    // Show result in modal
    progressBox.innerHTML = "";
    resultBox.style.display = "block";
    if (errors === 0) {
      resultBox.innerHTML =
        `<span class="ok">✓ Upload concluído!</span><br>` +
        `${doneActivities} atividade(s) enviadas para <strong>${platformLabel}</strong>.`;
    } else {
      resultBox.innerHTML =
        `<span class="ok">✓ ${doneActivities} atividade(s) enviadas</span> para <strong>${platformLabel}</strong>.<br>` +
        `<span class="err">✗ ${errors} erro(s)</span> — verifique o console para detalhes.`;
    }

    actions.style.display = "flex";
    actions.innerHTML = '<button class="btn-close" id="btn-close">Fechar</button>';
    shadow.getElementById("btn-close").addEventListener("click", () => {
      modalHost.remove();
      modalHost = null;
    });
    actions.className = "modal-footer";
  }
})();
