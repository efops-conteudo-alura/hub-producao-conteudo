// content-ferramentas-ia.js — injected into https://ferramentas-ia.alura.dev/*
//
// Protocol:
//   Extension → Content : FERRAMENTAS_IA_CHECK_STATUS    — is translation done?
//   Extension → Content : FERRAMENTAS_IA_TRIGGER_DOWNLOAD — click download button
//   Background ← Content: FERRAMENTAS_IA_ZIP_CAPTURED     — ZIP blob captured (base64)
//
// Technique: injects a MAIN-world script that overrides URL.createObjectURL so
// the ZIP blob is intercepted before the browser triggers the download.

(function () {
  "use strict";

  // ── 1. Inject MAIN-world interceptor ──────────────────────────────────────

  // Load the MAIN-world override as an external script (bypasses CSP that blocks inline scripts).
  // The extension URL is already whitelisted in the page's CSP.
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("injected-ferramentas-ia.js");
  // Do NOT call script.remove() — async external scripts may not execute if removed immediately
  (document.head || document.documentElement).appendChild(script);

  // ── 2. Relay MAIN-world message to background ─────────────────────────────

  window.addEventListener("message", function (event) {
    if (event.source !== window) return;
    if (event.data?.type !== "FERRAMENTAS_IA_ZIP_BLOB") return;

    chrome.runtime.sendMessage({
      type: "FERRAMENTAS_IA_ZIP_CAPTURED",
      base64: event.data.base64,
      mimeType: event.data.mimeType,
      size: event.data.size,
    });
  });

  // ── 3. Handle messages from popup/background ──────────────────────────────

  // ── 4. Inject "Enviar para seletor" button on activity pages ─────────────

  function normalizeText(str) {
    return str.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
  }

  async function fetchTaskData(url) {
    if (!url) return { title: "", text: "" };
    const resp = await fetch(url, { credentials: "include" });
    if (!resp.ok) return { title: "", text: "" };

    const raw = await resp.text();

    try {
      const json = JSON.parse(raw);
      if (json && typeof json.text === "string") return { title: json.title || "", text: json.text };
    } catch (_) {}

    const doc = new DOMParser().parseFromString(raw, "text/html");
    const el = doc.querySelector("pre") || doc.querySelector("main") || doc.querySelector("article") || doc.querySelector('[class*="content"]') || doc.body;
    const bodyText = el ? el.textContent.trim() : "";

    try {
      const json = JSON.parse(bodyText);
      if (json && typeof json.text === "string") return { title: json.title || "", text: json.text };
    } catch (_) {}

    return { title: "", text: bodyText };
  }

  function extractTaskLinksByType() {
    const facaLinks = [];
    const paraSaberLinks = [];
    document.querySelectorAll('a[href*="/tasks/"]').forEach(function (link) {
      const text = normalizeText(link.textContent);
      if (text === "faca como eu fiz") facaLinks.push(link.href);
      else if (text === "para saber mais" || text === "para saber mas") paraSaberLinks.push(link.href);
    });
    return { facaLinks, paraSaberLinks };
  }

  function sanitizeLessonTitle(title, lessonNumber) {
    var fallback = "Conteúdo da aula " + lessonNumber;
    if (!title || typeof title !== "string") return fallback;
    var t = title.trim();
    if (t.length < 5) return fallback;
    if (/^aula\b/i.test(t)) return fallback;
    return t;
  }

  function buildSeletorJson(baseJson, facaContents, paraSaberContents) {
    const lessons = Array.isArray(baseJson.lessons)
      ? [...baseJson.lessons].sort(function (a, b) { return a.lessonNumber - b.lessonNumber; })
      : [];

    return {
      courseId: baseJson.courseId,
      lessons: lessons.map(function (lesson, i) {
        const exercises = Array.isArray(lesson.exercises) ? lesson.exercises.map(function (ex) { return Object.assign({}, ex); }) : [];

        if (lesson.oQueAprendemos) {
          exercises.push({ title: "O que aprendemos", text: lesson.oQueAprendemos, kind: "HQ_EXPLANATION", dataTag: "WHAT_WE_LEARNED", alternatives: [] });
        }
        const facaData = facaContents[i];
        if (facaData && facaData.text) {
          exercises.push({ title: facaData.title || "Faça como eu fiz", text: facaData.text, kind: "TEXT_CONTENT", dataTag: "DO_AFTER_ME", alternatives: [] });
        }
        const paraSaberData = paraSaberContents[i];
        if (paraSaberData && paraSaberData.text) {
          exercises.push({ title: paraSaberData.title || "Para saber mais", text: paraSaberData.text, kind: "HQ_EXPLANATION", dataTag: "COMPLEMENTARY_INFORMATION", alternatives: [] });
        }

        return { lessonNumber: lesson.lessonNumber, title: sanitizeLessonTitle(lesson.title, lesson.lessonNumber), exercises: exercises };
      }),
    };
  }

  async function handleSendToSeletor() {
    const btn = document.getElementById("alura-revisor-seletor-btn");
    const statusEl = document.getElementById("alura-revisor-seletor-status");
    btn.disabled = true;
    statusEl.style.color = "";
    statusEl.textContent = "Coletando exercícios…";

    try {
      const form = document.querySelector('form[action*="/download_exercises/"]');
      const courseId = (form.getAttribute("action").match(/\/download_exercises\/(\d+)/) || [])[1];
      if (!courseId) throw new Error("courseId não encontrado na página");

      statusEl.textContent = "Baixando exercícios…";
      const resp = await fetch("/download_exercises/" + courseId, { method: "POST", credentials: "include" });
      if (!resp.ok) throw new Error("Erro ao baixar exercícios: " + resp.status);
      const baseJson = await resp.json();

      statusEl.textContent = "Buscando Faça como eu fiz e Para saber mais…";
      const links = extractTaskLinksByType();
      const facaContents = await Promise.all(links.facaLinks.map(fetchTaskData));
      const paraSaberContents = await Promise.all(links.paraSaberLinks.map(fetchTaskData));

      const completeJson = buildSeletorJson(baseJson, facaContents, paraSaberContents);

      statusEl.textContent = "Abrindo Hub…";
      const jsonStr = JSON.stringify(completeJson, null, 2);
      const filename = courseId + "-atividades-seletor.json";

      await chrome.storage.local.remove("aluraRevisorHubInjectStatus");
      await chrome.storage.local.set({ aluraRevisorPendingHubInject: { jsonStr: jsonStr, filename: filename } });

      for (let i = 0; i < 3; i++) {
        try { await chrome.runtime.sendMessage({ type: "OPEN_HUB_FOR_INJECT" }); break; }
        catch (_) { await new Promise(function (r) { setTimeout(r, 400); }); }
      }

      statusEl.style.color = "#2e7d32";
      statusEl.textContent = "✓ Enviado para o Hub!";
    } catch (e) {
      statusEl.style.color = "#c62828";
      statusEl.textContent = "Erro: " + e.message;
    } finally {
      btn.disabled = false;
    }
  }

  function tryInjectSeletorButton() {
    if (document.getElementById("alura-revisor-seletor-btn")) return;
    const form = document.querySelector('form[action*="/download_exercises/"]');
    if (!form) return;

    const btn = document.createElement("button");
    btn.id = "alura-revisor-seletor-btn";
    btn.type = "button";
    btn.textContent = "Enviar para seletor";
    btn.style.cssText = "margin-left:8px;padding:6px 14px;background:#1565c0;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:14px;font-weight:500;";

    const statusEl = document.createElement("span");
    statusEl.id = "alura-revisor-seletor-status";
    statusEl.style.cssText = "margin-left:10px;font-size:13px;";

    form.after(btn, statusEl);
    btn.addEventListener("click", handleSendToSeletor);

    seletorObserver.disconnect();
  }

  const seletorObserver = new MutationObserver(tryInjectSeletorButton);

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      tryInjectSeletorButton();
      seletorObserver.observe(document.documentElement, { childList: true, subtree: true });
    });
  } else {
    tryInjectSeletorButton();
    seletorObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
    // Check if page is loaded and translation is complete
    if (msg?.type === "FERRAMENTAS_IA_CHECK_STATUS") {
      const downloadBtn = document.querySelector(
        'button.TaskTranslator_downloadButton__eWo8f, button[class*="downloadButton"]'
      );
      const ready = !!(downloadBtn && downloadBtn.getAttribute("aria-disabled") !== "true" && !downloadBtn.disabled);
      sendResponse({ ok: true, onPage: true, ready });
      return true;
    }

    // Programmatically click the download button to trigger ZIP capture
    if (msg?.type === "FERRAMENTAS_IA_TRIGGER_DOWNLOAD") {
      const downloadBtn = document.querySelector(
        'button.TaskTranslator_downloadButton__eWo8f, button[class*="downloadButton"]'
      );
      if (!downloadBtn) {
        sendResponse({ ok: false, error: "Botão de download não encontrado. Aguarde a tradução terminar." });
        return true;
      }
      if (downloadBtn.getAttribute("aria-disabled") === "true" || downloadBtn.disabled) {
        sendResponse({ ok: false, error: "Tradução ainda não concluída. Aguarde 100%." });
        return true;
      }
      downloadBtn.click();
      sendResponse({ ok: true });
      return true;
    }
  });
})();
