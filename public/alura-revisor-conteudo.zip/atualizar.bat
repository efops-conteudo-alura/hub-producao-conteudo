@echo off
echo Baixando atualizacao do Revisor de Conteudo...

powershell -Command "try { (New-Object System.Net.WebClient).DownloadFile('https://hub-producao-conteudo.vercel.app/alura-revisor-conteudo.zip', '%TEMP%\ext-update.zip'); $size = (Get-Item '%TEMP%\ext-update.zip').length; if ($size -lt 10000) { throw ('Vercel: arquivo invalido (' + $size + ' bytes), tentando GitHub...') }; Expand-Archive -Path '%TEMP%\ext-update.zip' -DestinationPath '%~dp0' -Force -ErrorAction Stop; Write-Host 'Arquivos atualizados com sucesso!' -ForegroundColor Green } catch { Write-Host $_ -ForegroundColor Yellow; try { (New-Object System.Net.WebClient).DownloadFile('https://github.com/efops-conteudo-alura/alura-revisor-conteudo/archive/refs/heads/main.zip', '%TEMP%\ext-update-gh.zip'); Expand-Archive -Path '%TEMP%\ext-update-gh.zip' -DestinationPath '%TEMP%\ext-update-gh' -Force -ErrorAction Stop; Copy-Item '%TEMP%\ext-update-gh\alura-revisor-conteudo-main\*' -Destination '%~dp0' -Recurse -Force; Write-Host 'Arquivos atualizados via GitHub com sucesso!' -ForegroundColor Green } catch { Write-Host ('ERRO: ' + $_) -ForegroundColor Red; exit 1 } }"

if %errorlevel% neq 0 (
  echo.
  echo Falha na atualizacao. Verifique sua conexao ou fale com o suporte.
  pause
  exit /b 1
)

echo.
echo Feito! Agora:
echo 1. Acesse chrome://extensions
echo 2. Clique em "Recarregar" na extensao Revisor de Conteudo
echo.
pause
