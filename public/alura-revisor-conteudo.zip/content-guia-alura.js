// content-guia-alura.js — injected into https://guia.alura.dev/*
// Adds "Enviar para seletor" button next to "Enviar p/ Admin" on /status/* pages.
// Collects exercises (via /download_exercises/), O que aprendemos, Faça como eu fiz
// and Para saber mais, then sends to hub via OPEN_HUB_FOR_INJECT.

(function () {
  "use strict";

  function normalizeText(str) {
    return str.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
  }

  // Returns { title, text } — parses JSON responses (Faça/Para saber) or plain text (O que aprendemos)
  async function fetchTaskData(url) {
    if (!url) return { title: "", text: "" };
    const resp = await fetch(url, { credentials: "include" });
    if (!resp.ok) return { title: "", text: "" };

    const raw = await resp.text();

    // Try to parse as JSON directly
    try {
      const json = JSON.parse(raw);
      if (json && typeof json.text === "string") {
        return { title: json.title || "", text: json.text };
      }
    } catch (_) {}

    // Parse as HTML and try to find JSON inside the page
    const doc = new DOMParser().parseFromString(raw, "text/html");
    const el =
      doc.querySelector("pre") ||
      doc.querySelector("main") ||
      doc.querySelector("article") ||
      doc.querySelector('[class*="content"]') ||
      doc.body;
    const bodyText = el ? el.textContent.trim() : "";

    try {
      const json = JSON.parse(bodyText);
      if (json && typeof json.text === "string") {
        return { title: json.title || "", text: json.text };
      }
    } catch (_) {}

    // Fallback: plain text preserving line breaks
    return { title: "", text: bodyText };
  }

  // Returns { lessonNumber, oQueUrl, facaUrl, paraSaberUrl } for each lesson div
  function parseLessonLinks() {
    const lessons = [];
    document.querySelectorAll("div.lesson").forEach(function (lessonEl) {
      const h2 = lessonEl.querySelector("h2");
      if (!h2) return;

      const lessonNumMatch = (h2.firstChild && h2.firstChild.textContent || "").match(/(\d+)/);
      const lessonNumber = lessonNumMatch ? parseInt(lessonNumMatch[1], 10) : null;

      let oQueUrl = null, facaUrl = null, paraSaberUrl = null;

      h2.querySelectorAll('a[href*="/tasks/"]').forEach(function (link) {
        const text = normalizeText(link.textContent);
        if (text.includes("o que aprendemos")) oQueUrl = link.href;
        else if (text.includes("faca como eu fiz")) facaUrl = link.href;
        else if (text.includes("para saber mais") || text.includes("para saber mas")) paraSaberUrl = link.href;
      });

      lessons.push({ lessonNumber, oQueUrl, facaUrl, paraSaberUrl });
    });
    return lessons;
  }

  function buildSeletorJson(courseId, baseJson, lessonTaskData) {
    // Index fetched content by lessonNumber for fast lookup
    const byLesson = {};
    lessonTaskData.forEach(function (d) { byLesson[d.lessonNumber] = d; });

    const baseLessons = Array.isArray(baseJson.lessons)
      ? [...baseJson.lessons].sort(function (a, b) { return a.lessonNumber - b.lessonNumber; })
      : [];

    return {
      courseId: String(courseId),
      lessons: baseLessons.map(function (lesson) {
        const exercises = Array.isArray(lesson.exercises)
          ? lesson.exercises.map(function (ex) { return Object.assign({}, ex); })
          : [];

        const extra = byLesson[lesson.lessonNumber] || {};

        const oQueText = (extra.oQue && extra.oQue.text) || lesson.oQueAprendemos || "";
        if (oQueText) {
          exercises.push({ title: (extra.oQue && extra.oQue.title) || "O que aprendemos", text: oQueText, kind: "HQ_EXPLANATION", dataTag: "WHAT_WE_LEARNED", alternatives: [] });
        }
        if (extra.faca && extra.faca.text) {
          exercises.push({ title: extra.faca.title || "Faça como eu fiz", text: extra.faca.text, kind: "TEXT_CONTENT", dataTag: "DO_AFTER_ME", alternatives: [] });
        }
        if (extra.paraSaber && extra.paraSaber.text) {
          exercises.push({ title: extra.paraSaber.title || "Para saber mais", text: extra.paraSaber.text, kind: "HQ_EXPLANATION", dataTag: "COMPLEMENTARY_INFORMATION", alternatives: [] });
        }

        return { lessonNumber: lesson.lessonNumber, title: lesson.title || "Conteúdo da aula " + lesson.lessonNumber, exercises: exercises };
      }),
    };
  }

  async function handleSendToSeletor() {
    const btn = document.getElementById("alura-revisor-seletor-btn");
    const statusEl = document.getElementById("alura-revisor-seletor-status");
    btn.disabled = true;
    statusEl.style.color = "";
    statusEl.textContent = "Coletando exercícios…";

    try {
      const courseInput = document.querySelector('input[name="course_code"]');
      const courseId = courseInput ? courseInput.value.trim() : null;
      if (!courseId) throw new Error("course_code não encontrado na página");

      statusEl.textContent = "Baixando exercícios…";
      const resp = await fetch("/download_exercises/" + courseId, { method: "GET", credentials: "include" });
      if (!resp.ok) throw new Error("Erro ao baixar exercícios: " + resp.status);
      const baseJson = await resp.json();

      statusEl.textContent = "Lendo links das aulas…";
      const lessonLinks = parseLessonLinks();

      statusEl.textContent = "Buscando Faça como eu fiz e Para saber mais…";
      const lessonTaskData = await Promise.all(
        lessonLinks.map(async function (lesson) {
          const [oQue, faca, paraSaber] = await Promise.all([
            fetchTaskData(lesson.oQueUrl),
            fetchTaskData(lesson.facaUrl),
            fetchTaskData(lesson.paraSaberUrl),
          ]);
          return { lessonNumber: lesson.lessonNumber, oQue, faca, paraSaber };
        })
      );

      const completeJson = buildSeletorJson(courseId, baseJson, lessonTaskData);

      statusEl.textContent = "Abrindo Hub…";
      const jsonStr = JSON.stringify(completeJson, null, 2);
      const filename = courseId + "-atividades-seletor.json";

      await chrome.storage.local.remove("aluraRevisorHubInjectStatus");
      await chrome.storage.local.set({ aluraRevisorPendingHubInject: { jsonStr: jsonStr, filename: filename } });

      for (let i = 0; i < 3; i++) {
        try { await chrome.runtime.sendMessage({ type: "OPEN_HUB_FOR_INJECT" }); break; }
        catch (_) { await new Promise(function (r) { setTimeout(r, 400); }); }
      }

      statusEl.style.color = "#2e7d32";
      statusEl.textContent = "✓ Enviado para o Hub!";
    } catch (e) {
      statusEl.style.color = "#c62828";
      statusEl.textContent = "Erro: " + e.message;
    } finally {
      btn.disabled = false;
    }
  }

  function injectButton() {
    if (document.getElementById("alura-revisor-seletor-btn")) return;

    const sendAdminForm = document.getElementById("send-admin-form");
    if (!sendAdminForm) return;

    const btn = document.createElement("button");
    btn.id = "alura-revisor-seletor-btn";
    btn.type = "button";
    btn.textContent = "Enviar para seletor";
    btn.style.cssText = "margin-left:8px;padding:4px 12px;background:#1565c0;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:14px;font-weight:500;";

    const statusEl = document.createElement("span");
    statusEl.id = "alura-revisor-seletor-status";
    statusEl.style.cssText = "display:block;margin-top:4px;font-size:12px;";

    sendAdminForm.after(btn, statusEl);
    btn.addEventListener("click", handleSendToSeletor);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", injectButton);
  } else {
    injectButton();
  }
})();
