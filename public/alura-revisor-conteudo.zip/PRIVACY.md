# Política de Privacidade — Alura Revisor de Conteúdo

*Última atualização: abril de 2026*

## 1. Sobre esta extensão

O Alura Revisor de Conteúdo é uma extensão de navegador de uso **exclusivamente interno**, destinada à equipe de produção de conteúdo da Alura. Ela não está disponível para uso público geral.

## 2. Dados que a extensão acessa

Para executar suas funções, a extensão acessa as seguintes informações:

- **Conteúdo de cursos**: títulos, transcrições de vídeos, links e metadados dos cursos nas plataformas `cursos.alura.com.br` e `app.aluracursos.com`. Esses dados são lidos diretamente das páginas e usados apenas para geração de relatórios de revisão e operações de edição no próprio curso.
- **Credenciais de acesso**: tokens de GitHub, video-uploader e chave da API de IA, fornecidos pelo Hub de Conteúdo após login. Esses tokens são armazenados em `chrome.storage.session` (apagados ao fechar o navegador) e nunca são transmitidos a serviços não listados nesta política.
- **Credenciais do Dropbox**: token OAuth2 armazenado em `chrome.storage.local` apenas quando o usuário conecta o Dropbox voluntariamente. O token é usado somente para listar e baixar vídeos do Dropbox para upload no video-uploader da Alura.

## 3. Dados transmitidos a serviços externos

| Serviço | Dado transmitido | Finalidade |
|---|---|---|
| `hub-producao-conteudo.vercel.app` | Cookie de sessão (login) | Autenticação e obtenção de credenciais |
| `api.github.com` | Token GitHub, conteúdo de arquivos SVG | Fork de repositórios e upload de ícones |
| `video-uploader.alura.com.br` | Arquivos de vídeo, token do uploader | Upload e geração de legendas |
| `api.anthropic.com` | Transcrições de vídeos e títulos de seções | Geração de sugestões de nomes via IA |
| `api.dropboxapi.com` | Token Dropbox | Download de vídeos para upload |
| `*.amazonaws.com` | Arquivos de material de apoio | Upload para CDN via presigned URL |

## 4. Dados não coletados

A extensão **não coleta**, **não armazena** e **não transmite**:

- Dados de navegação fora dos domínios da Alura e dos serviços listados acima
- Informações pessoais de usuários dos cursos (alunos)
- Histórico de navegação geral
- Conteúdo de outras abas abertas no navegador

## 5. Armazenamento local

A extensão usa `chrome.storage.local` para salvar:

- Histórico das últimas 5 auditorias de revisão (dados de cursos da Alura)
- Progresso de operações em andamento (para retomada após fechamento da aba)
- Histórico dos últimos 30 uploads de material
- Credenciais do Dropbox (quando conectado pelo usuário)

Esses dados ficam armazenados apenas no dispositivo do usuário e podem ser removidos a qualquer momento desinstalando a extensão ou limpando os dados de extensões nas configurações do Chrome.

## 6. Compartilhamento de dados

Os dados acessados pela extensão são usados **exclusivamente** para as operações descritas nesta política, dentro do fluxo de trabalho interno da Alura. Nenhum dado é vendido, compartilhado com anunciantes ou transmitido a serviços não listados acima.

## 7. Contato

Dúvidas sobre esta política podem ser enviadas para a equipe de produção de conteúdo da Alura.
